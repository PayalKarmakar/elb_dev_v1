export const inputTypes = [
  { type: "text" },
  { type: "textarea" },
  { type: "checkbox" },
  { type: "radio" },
  { type: "dropdown" },
  { type: "number" },
];
