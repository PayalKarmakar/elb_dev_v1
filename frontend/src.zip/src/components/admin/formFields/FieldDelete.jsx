import React from "react";

const FieldDelete = () => {
  return <div>FieldDelete</div>;
};

export default FieldDelete;
