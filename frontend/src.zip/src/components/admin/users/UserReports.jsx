import React from "react";

const UserReports = () => {
  return <div>UserReports</div>;
};

export default UserReports;
