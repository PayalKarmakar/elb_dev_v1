import React from "react";

const UserReviews = () => {
  return <div>UserReviews</div>;
};

export default UserReviews;
