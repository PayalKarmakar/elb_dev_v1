import React from "react";

const PersonalInfo = () => {
  return <div>PersonalInfo</div>;
};

export default PersonalInfo;
