import React from "react";

const UserPosts = () => {
  return <div>UserPosts</div>;
};

export default UserPosts;
