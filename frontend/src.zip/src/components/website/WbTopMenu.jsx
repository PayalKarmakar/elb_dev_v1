import React from "react";

const WbTopMenu = () => {
  return <div>WbTopMenu</div>;
};

export default WbTopMenu;
