const DashboardGraphBox = () => {
  return (
    <div className="col-xl col-md-6">
      <div style={{ minHeight: "300px", background: "#fff" }}></div>
    </div>
  );
};

export default DashboardGraphBox;
