const ImageLoading = () => {
  return <div>Loading ...</div>;
};
export default ImageLoading;
