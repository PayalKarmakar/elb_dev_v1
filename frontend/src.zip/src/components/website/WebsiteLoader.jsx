const WebsiteLoader = () => {
  return <div>Getting data ...</div>;
};
export default WebsiteLoader;
