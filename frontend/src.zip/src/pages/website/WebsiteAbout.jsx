import React from "react";

const WebsiteAbout = () => {
  return (
    <>
      <section className="w-breadcrumb-area" style={{ backgroundColor: "red" }}>
        <div className="container">
          <div className="row">
            <div className="col-auto">
              <div
                className="position-relative z-2"
                data-aos="fade-up"
                data-aos-duration="1000"
                data-aos-easing="linear"
              >
                AAA
              </div>
            </div>
          </div>
        </div>
      </section>
      WebsiteAbout
    </>
  );
};

export default WebsiteAbout;
