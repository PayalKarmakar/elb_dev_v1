import React from "react";

const AdminDashboard = () => {
  document.title = `Dashboard | ${import.meta.env.VITE_APP_TITLE}`;

  return <div>AdminDashboard</div>;
};

export default AdminDashboard;
