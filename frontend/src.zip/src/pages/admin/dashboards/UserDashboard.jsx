import React from "react";

const UserDashboard = () => {
  return <div>UserDashboard</div>;
};

export default UserDashboard;
